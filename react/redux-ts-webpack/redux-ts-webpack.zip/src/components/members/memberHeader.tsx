import * as React from 'react';

export const MemberHeader: React.StatelessComponent<{}> = () => {
  return (
    <tr>
      <td>Avatar</td>
      <td>Id</td>
      <td>Name</td>
    </tr>
  );
}
