module.exports = {
  plugins: {
    'autoprefixer': {}
  }
};
