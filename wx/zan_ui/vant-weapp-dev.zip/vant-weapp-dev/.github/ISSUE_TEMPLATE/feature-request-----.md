---
name: Feature request 功能需求
about: Suggest an idea for this project

---

注意：请按照下面的模板来新建 issue，不规范的 issue 会被立即关闭.

**你需要的功能是？**
描述一下你需要的功能，用于解决什么问题

**你期望 API 是什么样的？**
描述一下你期望的 API 形式
