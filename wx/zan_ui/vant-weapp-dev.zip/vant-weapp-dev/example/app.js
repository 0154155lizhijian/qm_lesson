App({
  globalData: {}
});
